# https://dodona.ugent.be/nl/courses/1286/series/14352/activities/1144225403

def som(t1, t2):
    return (t1[0]+t2[0], t1[1]+t2[1])
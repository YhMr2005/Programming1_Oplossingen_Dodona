# https://dodona.ugent.be/nl/courses/1286/series/14344/activities/554690920

print( (2*3)/4 + (5-6/7)*8 )
print( ((12*13)/14 + (15-16)/17)*18 )

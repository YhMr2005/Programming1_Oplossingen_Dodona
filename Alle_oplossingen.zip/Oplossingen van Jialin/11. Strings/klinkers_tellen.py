# https://dodona.ugent.be/nl/courses/1286/series/14351/activities/1095693228

woord = input()

print("A:", woord.lower().count("a"))
print("E:", woord.lower().count("e"))
print("I:", woord.lower().count("i"))
print("O:", woord.lower().count("o"))
print("U:", woord.lower().count("u"))

# https://dodona.ugent.be/nl/courses/1286/series/14344/activities/385064229

print(str(14 + 535%24) + ":00")

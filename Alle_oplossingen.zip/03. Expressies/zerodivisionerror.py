# https://dodona.ugent.be/nl/courses/1286/series/14344/activities/270198713

print(5/0)

# https://dodona.ugent.be/nl/courses/1286/series/14344/activities/1886659767

print(0.6*24.95 + 3 + 59*(0.6*24.95 + 0.75))

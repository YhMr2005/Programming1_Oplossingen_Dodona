# https://dodona.ugent.be/nl/courses/1286/series/14346/activities/723647984

a = int(input())
b = int(input())
c = int(input())

print("maximum:", max(a,b,c))
print("minimum:", min(a,b,c))
print('gemiddelde: {:.2f}'.format(sum((a,b,c,))/3))

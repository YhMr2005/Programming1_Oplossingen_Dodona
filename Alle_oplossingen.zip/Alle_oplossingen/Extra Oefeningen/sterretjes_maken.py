getal = int(input())

for i in range(1, getal):
    print(i*'*')
for i in range(getal, 0, -1):
    print(i*'*')
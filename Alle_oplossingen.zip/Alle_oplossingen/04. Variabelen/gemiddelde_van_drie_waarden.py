# https://dodona.ugent.be/nl/courses/1286/series/14345/activities/1633117996
'''
Dit programma berekent het gemiddelde 
van 3 getallen.
'''
# Getallen
var1 = 9.4
var2 = 5.9
var3 = 7.5

# Totaal
tot = var1 + var2 + var3

# Gemiddelde
gem = tot / 3

# Print
print(gem)

# https://dodona.ugent.be/nl/courses/1286/series/14345/activities/1614600361

# straal van cirkel
straal = 2.73

# waarde van π
pi = 3.141592653589793

oppervlakte = straal * straal * pi

print("De oppervlakte van een cirkel met straal", straal, "is", str(oppervlakte) + ".")

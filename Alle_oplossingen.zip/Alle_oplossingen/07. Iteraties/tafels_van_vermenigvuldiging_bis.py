# https://dodona.ugent.be/nl/courses/1286/series/14348/activities/1169713984

getal = int(input())

i = 1
while i <= 10:
    print("{} * {} = {}".format(i, getal, i*getal))
    i += 1

# https://dodona.ugent.be/nl/courses/1286/series/14348/activities/775169160

getal = int(input())

for i in range(1, 11):
    print("{} * {} = {}".format(i, getal, i*getal))

# https://dodona.ugent.be/nl/courses/1286/series/14350/activities/576540834

waarde = input()
while waarde != waarde.lower():
    print("Invalid answer!")
    waarde = input()
print("The user entered:", waarde)


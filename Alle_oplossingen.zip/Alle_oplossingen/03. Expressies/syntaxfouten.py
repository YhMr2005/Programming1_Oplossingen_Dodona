# https://dodona.ugent.be/nl/courses/1286/series/14344/activities/609820670

print( "Een boodschap." )
print( "Een boodschap" )
print( 'Een boodschapf"' )

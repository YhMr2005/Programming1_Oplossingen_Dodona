# https://dodona.ugent.be/nl/courses/1286/series/14349/activities/750340336

def oppervlakte_van_driehoek( basis, hoogte ):
    opp = 0.5 * basis * hoogte
    output = "Een driehoek met basis " + str(basis) + " en hoogte " + str(hoogte) + " heeft oppervlakte " + str(opp)
    return output

# https://dodona.ugent.be/nl/courses/1286/series/14346/activities/664835737

from random import random


print(round(random()*10))

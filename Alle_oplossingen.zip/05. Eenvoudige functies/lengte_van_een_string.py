# https://dodona.ugent.be/nl/courses/1286/series/14346/activities/1767098525

a = input()
print(len(a))

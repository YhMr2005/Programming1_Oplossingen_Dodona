# https://dodona.ugent.be/nl/courses/1286/series/14346/activities/1422122823
from math import sqrt
a = float(input())
b = float(input())

print("Lengte van de schuine zijde: {:.3f}".format(sqrt(a**2 + b**2)))

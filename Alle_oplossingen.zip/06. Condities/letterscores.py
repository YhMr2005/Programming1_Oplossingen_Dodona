# https://dodona.ugent.be/nl/courses/1286/series/14347/activities/774332532

cijfer = int(input())

if cijfer < 60:
    print('F')
elif cijfer < 70:
    print('D')
elif cijfer < 80:
    print('C')
elif cijfer < 90:
    print('B')
else:
    print('A')